<?php
session_start();
/**
 * Created by PhpStorm.
 * User: Luiz Felipe
 * Date: 09/10/2017
 * Time: 23:51
 */

var_dump($_SESSION);

#exit();

session_destroy();